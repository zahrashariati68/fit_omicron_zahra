﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using Wifi.PlaylistEditor.Core;
using Id3;
using System.IO;

namespace Wifi.PlaylistEditor.PlaylistItems
{
    public class PlaylistItem : IPlaylistItem
    {
        private string _title;
        private string _artist;
        private TimeSpan _duration;
        private string _path;
        private Image _thumbnail;
        private string _musicFile;
        private Mp3 _mp3;

        public PlaylistItem(string musicFile, string title, string artist, TimeSpan duration, Image thumbnail)
        {
            _title = title;
            _artist = artist;
            _duration = duration;
            _thumbnail = thumbnail;
            _musicFile = musicFile;
            _mp3 = new Mp3(_musicFile);
        }
        public string Title {
            get {
                 
                Id3Tag tag = _mp3.GetTag(Id3TagFamily.Version2X); 
                return tag.Title;
            }
        }

        public string Artist
        {
            get
            { 
                Id3Tag tag = _mp3.GetTag(Id3TagFamily.Version2X);
                return tag.Artists;
            }
        }

        public TimeSpan Duration
        {
            get
            { 
                Id3Tag tag = _mp3.GetTag(Id3TagFamily.Version2X);
                return tag.Length;
            }
        }

        public string Path
        {
            get
            { 
                Id3Tag tag = _mp3.GetTag(Id3TagFamily.Version2X);
                return tag.AudioFileUrl;
                //return (Directory.EnumerateFiles("C:\\dir", tag.Title, SearchOption.AllDirectories)).ToString(); 
            }
        }

        public Image Thumbnail
        {
            get
            { 
                Id3Tag tag = _mp3.GetTag(Id3TagFamily.Version2X);
                return;// tag.Pictures;
            }
        }
    }
}
