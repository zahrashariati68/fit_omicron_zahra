﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using Wifi.PlaylistEditor.Core;
using Wifi.PlaylistEditor.PlaylistItems;
using Wifi.PlaylistEditor.Repositories;

namespace Wifi.PlaylistEditor
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
            Playlist myFavorite1= new Playlist("My Favorite","Zahra");
            PlaylistItem song1 = new PlaylistItem("C:\\Users\\ZahSha00\\Downloads\\Muse-Uprising-HQ_514434.mp3", "Uprising","Muse",,);
            PlaylistRepository plRepo= new PlaylistRepository("12","34");
            myFavorite1.Add(song1);
        }
    }
}
