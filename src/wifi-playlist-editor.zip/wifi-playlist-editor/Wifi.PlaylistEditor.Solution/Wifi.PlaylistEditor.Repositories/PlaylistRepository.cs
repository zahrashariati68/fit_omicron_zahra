﻿using PlaylistsNET.Content;
using PlaylistsNET.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Wifi.PlaylistEditor.Core;

namespace Wifi.PlaylistEditor.Repositories
{
    public class PlaylistRepository : IPlaylistRepository
    {
        private string _extension;
        private string _description;

        public PlaylistRepository(string extension, string description) 
        {
            _extension = extension;
            _description = description;

        }
        public string Extension 
        {
            get { return _extension; }
        }

        public string Description 
        {
            get { return _description; } 
        }

        public IPlaylist Load(string playlistPath)
        { 
            var parser = PlaylistParserFactory.GetPlaylistParser(".m3u");
            IBasePlaylist playlist = parser.GetFromString(playlistPath);

          //  List<string> paths = playlist.GetTracksPaths();
            return (IPlaylist)playlist;
        }

        public bool Save(string playlistPath, IPlaylist playlistToSave)
        {
            M3uPlaylist playlist = (M3uPlaylist)playlistToSave;//new M3uPlaylist();
            playlist.IsExtended = true;
            playlist.Path = playlistPath;
            //playlist.PlaylistEntries.Add(new M3uPlaylistEntry()
            //{
            //    Album = "New album",
            //    AlbumArtist = "",
            //    Duration = TimeSpan.FromSeconds(175),
            //    Path = @"C:\Music\song.mp3",
            //    Title = "Track Title"
            //});

            M3uContent content = new M3uContent();
            if (content.ToText(playlist) != null)
                return true;
            return false;

        }
    }
}
